export const data = [
    
    {
        id:1,
        img:'./img/pock1.png',
        name: 'BULBASAUR'
    },
    {
        id:2,
        img:'./img/pock2.png',
        name: 'IVYSAUR'
    },
    {
        id:3,
        img:'./img/pock3.png',
        name: 'VENUSAUR'
    },
    {
        id:4,
        img:'./img/pock1.png',
        name: 'BULBASAUR'
    },
    {
        id:5,
        img:'./img/pock2.png',
        name: 'IVYSAUR'
    },
    {
        id:6,
        img:'./img/pock3.png',
        name: 'VENUSAUR'
    } ,
    {
        id:7,
        img:'./img/pock1.png',
        name: 'BULBASAUR'
    },
    {
        id:8,
        img:'./img/pock2.png',
        name: 'IVYSAUR'
    },
    {
        id:9,
        img:'./img/pock3.png',
        name: 'VENUSAUR'
    }   
    
]